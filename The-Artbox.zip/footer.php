<footer>
        <p>
            <strong>© THE ARTBOX</strong> - <em>Tous droits réservés</em>
        </p>
</footer>